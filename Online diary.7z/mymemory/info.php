<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Online diary</title>
    <?php require_once 'helper/script_style.php';?>
    
</head>
<body>
<?php include 'components/header.php';?>
<div class="background">
        <div class="about">
                <div class="header">
                    <h3>Contact us</h3>
                </div>
    <p>
         Contact number:7044317767/7044197767.<br>
         Whatsapp no:7044317767.<br>
         Email ID:sugamkarmakar338@gmail.com.<br>
         Facebook page:Diary.<br>
         Instagram profile:diary_pen.<br>
    </p>
    </div>
    </div>
    <?php include 'components/footer.php';?>
</body>
</html>