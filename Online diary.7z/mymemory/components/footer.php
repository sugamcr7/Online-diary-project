<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>
<footer class="mainfooter" role="contentinfo">
  <div class="footer-middle">
  <div class="container">
    <div class="row">
      <div class="col-md-3 col-sm-6">
        
        <div class="footer-pad">
          <h4>DISCRIPTION</h4>
          <ul class="list-unstyled">
          <li><a href="about.php">ABOUT</a></li>
            <li><a href="info.php">INFO</a></li>
          </ul>
        </div>
      </div>
      <div class="col-md-3 col-sm-6">
        
        <div class="footer-pad">
          <h4>ADDRESS</h4>
          <ul class="list-unstyled">
            <p>138/2,Dr. H M Road.<br>Newbarrackpur.<br>Kolkata,India</p>
            
            
            
          </ul>
        </div>
      </div>
      
    	<div class="col-md-3">
    		<h4>Follow Us</h4>
            <ul class="social-network social-circle">
            <a href="https://www.facebook.com/profile.php?id=100010790715461"><i class="fa fa-facebook" style="font-size:25px;"></i> Facebook</a><br>
            <a href="https://www.instagram.com/sugam__cr7/"><i class="fa fa-instagram" style="font-size:25px;color:deeppink ;"></i> Instagram</a><br>
            <a href="https://twitter.com/SugamCr7"><i class="fa fa-twitter" style="font-size:25px;color:deepskyblue" ></i> Twitter</a>
            </ul>				
		</div>
    </div>
    
	<div class="row">
		<div class="col-md-12 copy">
			<p class="text-center">Design by @ Sugam kr karmakar</p>
		</div>
	</div>


  </div>
  </div>
</footer>

</body>
</html>