<div class="header">
  <h4 class="logo">MEMORIES
  <div class="header-right">
    <a href="home.php">Home</a>
    <a href="about.php">About us</a>
    <a href="contact.php">Contact</a>
    
    <a href="register.php">Register</a>
    <a href="login.php">Login</a>
    </h4>
  </div>
</div> 
