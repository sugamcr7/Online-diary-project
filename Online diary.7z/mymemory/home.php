
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Online diary</title>
    <?php require_once 'helper/script_style.php';?>

</head>
<body>
<?php include 'components/header.php';?>
    <h1>Memory... is the diary that<br>
           we all carry about with us. </h1>
<?php include 'components/footer.php';?>
    
</body>
</html>
