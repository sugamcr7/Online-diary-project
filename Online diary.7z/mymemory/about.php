
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Online diary</title>
    <?php require_once 'helper/script_style.php';?>
    
</head>
<body>
<?php include 'components/header.php';?>
<div class="background">
        <div class="about">
                <div class="header">
                    <h3>About us</h3>
                </div>
    <p>A diary is a record (originally in handwritten format) with discrete entries arranged by date<br>
     reporting on what has happened over the course of a day or other period. A personal diary may include<br>
     a person's experiences, thoughts, and/or feelings, excluding comments on current events outside the<br>
     writer's direct experience. Someone who keeps a diary is known as a diarist. Diaries undertaken for<br>
     institutional purposes play a role in many aspects of human civilization, including government records<br>
     (e.g. Hansard), business ledgers, and military records. In British English, the word may also denote a <br>
     preprinted journal format. A diary is a collection of notes.<br>
     Today the term is generally employed for personal diaries, normally intended to remain private or to <br>
     have a limited circulation amongst friends or relatives. The word "journal" may be sometimes used for <br>
     "diary," but generally a diary has (or intends to have) daily entries, whereas journal-writing can be <br>
     less frequent.
     Although a diary may provide information for a memoir, autobiography or biography, it is generally <br>
     written not with the intention of being published as it stands, but for the author's own use. In recent<br>
     years, however, there is internal evidence in some diaries (e.g. those of Ned Rorem, Alan Clark, Tony <br>
     Benn or Simon Gray) that they are written with eventual publication in mind, with the intention of <br>
     self-vindication (pre- or posthumous), or simply for profit.<br>
    </p>
    </div>
    </div>
    <?php include 'components/footer.php';?>
</body>
</html>