<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Online diary</title>
    <?php require_once 'helper/script_style.php';?>
    
</head>
<body>
   <div class="center">
      <h1 class="ml13">WELCOME    TO    ONLINE    DIARY </h1><br><br>
     <a href="home.php"> <button type="button" class="btn btn-outline-danger">Explore Now</button></a>
</body>
</html>
<script src="javascript/java.js"></script> 